package com.linko.offline

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import com.google.android.gms.nearby.connection.Payload
import java.util.UUID

private const val SERVICE_ID = "com.linko.offline.nearby"
private val Ink = Color(0xFF10101B)
private val Violet = Color(0xFF8B5CF6)
private val Cyan = Color(0xFF22D3EE)

class MainActivity : ComponentActivity() {
    private val client by lazy { Nearby.getConnectionsClient(this) }
    private val userId = UUID.randomUUID().toString().take(8).uppercase()
    private var onStatus: ((String) -> Unit)? = null
    private var onPeer: ((String, String) -> Unit)? = null
    private var onMessage: ((String) -> Unit)? = null
    private var pendingEndpoint: String? = null
    private var connectedEndpoint: String? = null

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.values.all { it }) startNearby() else onStatus?.invoke("لازم تسمح بأذونات الأجهزة القريبة لتشغيل الاتصال")
    }

    private fun requiredPermissions(): Array<String> = when {
        Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE, Manifest.permission.NEARBY_WIFI_DEVICES)
        Build.VERSION.SDK_INT >= 31 -> arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE)
        Build.VERSION.SDK_INT >= 29 -> arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        else -> arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION)
    }

    private fun permissionsGranted() = requiredPermissions().all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }

    private fun startNearby() {
        onStatus?.invoke("بنبحث عن أجهزة LINKO القريبة…")
        val strategy = Strategy.P2P_CLUSTER
        client.startAdvertising(userId, SERVICE_ID, connectionLifecycleCallback,
            AdvertisingOptions.Builder().setStrategy(strategy).build())
            .addOnSuccessListener { onStatus?.invoke("جهازك ظاهر للأجهزة القريبة") }
            .addOnFailureListener { onStatus?.invoke("تعذر تشغيل الظهور: ${it.localizedMessage}") }
        client.startDiscovery(SERVICE_ID, endpointDiscoveryCallback,
            DiscoveryOptions.Builder().setStrategy(strategy).build())
            .addOnFailureListener { onStatus?.invoke("تعذر البحث: ${it.localizedMessage}") }
    }

    private val endpointDiscoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            onPeer?.invoke(id, info.endpointName)
            onStatus?.invoke("لقينا جهاز قريب: ${info.endpointName}")
        }
        override fun onEndpointLost(id: String) { onStatus?.invoke("جهاز خرج من النطاق") }
    }

    private val connectionLifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            pendingEndpoint = id
            onStatus?.invoke("طلب اتصال من ${info.endpointName} — كود التأكيد ${info.authenticationDigits}")
            // The first prototype accepts after the user explicitly taps the discovered device.
        }
        override fun onConnectionResult(id: String, result: ConnectionResolution) {
            if (result.status.isSuccess) {
                connectedEndpoint = id
                pendingEndpoint = null
                onStatus?.invoke("متصل بنجاح — تقدر تبعت رسالة")
            } else onStatus?.invoke("الاتصال لم يكتمل")
        }
        override fun onDisconnected(id: String) {
            if (connectedEndpoint == id) connectedEndpoint = null
            onStatus?.invoke("الاتصال اتقفل")
        }
    }

    private fun connectTo(id: String) {
        onStatus?.invoke("بنطلب الاتصال…")
        client.requestConnection(userId, id, connectionLifecycleCallback)
            .addOnFailureListener { onStatus?.invoke("فشل طلب الاتصال: ${it.localizedMessage}") }
    }

    private fun acceptPending() {
        val id = pendingEndpoint ?: return
        client.acceptConnection(id, object : PayloadCallback() {
            override fun onPayloadReceived(endpointId: String, payload: Payload) {
                if (payload.type == Payload.Type.BYTES) payload.asBytes()?.toString(Charsets.UTF_8)?.let { onMessage?.invoke(it) }
            }
            override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {}
        }).addOnFailureListener { onStatus?.invoke("تعذر قبول الاتصال") }
    }

    private fun sendMessage(text: String) {
        val id = connectedEndpoint ?: run { onStatus?.invoke("اتصل بجهاز الأول"); return }
        client.sendPayload(id, Payload.fromBytes(text.toByteArray(Charsets.UTF_8)))
            .addOnFailureListener { onStatus?.invoke("فشل إرسال الرسالة") }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var status by remember { mutableStateOf("جاهز — شغّل البحث عن أجهزة قريبة") }
            var peerList by remember { mutableStateOf(listOf<Pair<String, String>>()) }
            var messages by remember { mutableStateOf(listOf("أهلًا بيك في LINKO 👋")) }
            var incomingRequest by remember { mutableStateOf(false) }
            onStatus = { runOnUiThread { status = it; incomingRequest = pendingEndpoint != null } }
            onPeer = { id, name -> runOnUiThread { if (peerList.none { it.first == id }) peerList = peerList + (id to name) } }
            onMessage = { msg -> runOnUiThread { messages = messages + "الطرف الآخر: $msg" } }
            LinkoApp(userId, status, peerList, messages, incomingRequest,
                onScan = { if (permissionsGranted()) startNearby() else permissionLauncher.launch(requiredPermissions()) },
                onConnect = { connectTo(it) },
                onAccept = { acceptPending(); incomingRequest = false },
                onSend = { sendMessage(it); messages = messages + "أنت: $it" })
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        client.stopAdvertising(); client.stopDiscovery(); client.stopAllEndpoints()
    }
}

@Composable
private fun LinkoApp(
    userId: String, status: String, peers: List<Pair<String, String>>, messages: List<String>,
    incomingRequest: Boolean, onScan: () -> Unit, onConnect: (String) -> Unit,
    onAccept: () -> Unit, onSend: (String) -> Unit
) {
    var tab by remember { mutableStateOf(0) }
    var draft by remember { mutableStateOf("") }
    val gradient = Brush.linearGradient(listOf(Violet, Color(0xFFEC4899), Cyan))
    MaterialTheme(colorScheme = darkColorScheme(primary = Violet, secondary = Cyan, background = Ink, surface = Color(0xFF1B1B2B))) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = Color(0xFF171725)) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Explore, null) }, label = { Text("قريبين") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Chat, null) }, label = { Text("الشات") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Face, null) }, label = { Text("استيكرات") })
                NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("حسابي") })
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp)) {
                Spacer(Modifier.height(22.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(gradient, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Bolt, null, tint = Color.White) }
                    Spacer(Modifier.width(10.dp))
                    Column { Text("LINKO", fontSize = 25.sp, fontWeight = FontWeight.Black, color = Color.White); Text("OFFLINE • CONNECTED", fontSize = 10.sp, color = Cyan, letterSpacing = 2.sp) }
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Default.WifiOff, null, tint = Cyan)
                }
                Spacer(Modifier.height(22.dp))
                when (tab) {
                    0 -> {
                        Text("اتصل بالعالم القريب", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("رسائلك تفضل بين أجهزتكم — بدون إنترنت", color = Color.LightGray, fontSize = 13.sp)
                        Spacer(Modifier.height(18.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202039)), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(18.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Radar, null, tint = Cyan); Spacer(Modifier.width(8.dp)); Text("اكتشاف الأجهزة القريبة", color = Color.White, fontWeight = FontWeight.Bold) }
                                Spacer(Modifier.height(8.dp)); Text(status, color = Color.LightGray, fontSize = 12.sp)
                                Spacer(Modifier.height(14.dp))
                                Button(onClick = onScan, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Icon(Icons.Default.Search, null); Spacer(Modifier.width(8.dp)); Text("ابدأ البحث") }
                                if (incomingRequest) { Spacer(Modifier.height(8.dp)); OutlinedButton(onClick = onAccept, modifier = Modifier.fillMaxWidth()) { Text("قبول طلب الاتصال") } }
                            }
                        }
                        Spacer(Modifier.height(20.dp)); Text("الأجهزة المكتشفة", color = Color.White, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        if (peers.isEmpty()) Text("مفيش أجهزة ظاهرة لسه. افتح LINKO على موبايل تاني واضغط ابدأ البحث.", color = Color.Gray, fontSize = 13.sp)
                        LazyColumn { items(peers) { (id, name) -> Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1B2B))) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.PhoneAndroid, null, tint = Cyan); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(name, color = Color.White); Text(id.take(8), color = Color.Gray, fontSize = 11.sp) }; Button(onClick = { onConnect(id) }) { Text("اتصال") } } } } }
                    }
                    1 -> {
                        Text("المحادثة التجريبية", fontSize = 24.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        Text("نسخة أولية لإرسال النصوص بين جهازين", color = Color.Gray, fontSize = 12.sp)
                        Spacer(Modifier.height(14.dp))
                        LazyColumn(Modifier.weight(1f).fillMaxWidth()) { items(messages) { msg -> Text(msg, color = Color.White, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Color(0xFF25253B), RoundedCornerShape(14.dp)).padding(12.dp)) } }
                        Row(verticalAlignment = Alignment.CenterVertically) { OutlinedTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.weight(1f), placeholder = { Text("اكتب رسالة…") }, singleLine = true); IconButton(onClick = { if (draft.isNotBlank()) { onSend(draft); draft = "" } }) { Icon(Icons.Default.Send, null, tint = Cyan) } }
                        Spacer(Modifier.height(10.dp))
                    }
                    2 -> FeaturePlaceholder("استوديو الاستيكرات", "المرحلة القادمة: قص الصور، إضافة النصوص، وحفظ الاستيكرات محليًا.", Icons.Default.AutoAwesome)
                    else -> FeaturePlaceholder("ملفك الشخصي", "معرّف LINKO الخاص بك: $userId\nهنضيف صورة الحساب وQR Code في المرحلة القادمة.", Icons.Default.QrCode2)
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun FeaturePlaceholder(title: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(icon, null, tint = Cyan, modifier = Modifier.size(54.dp)); Spacer(Modifier.height(14.dp)); Text(title, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); Text(description, color = Color.LightGray, fontSize = 14.sp) } }
}
